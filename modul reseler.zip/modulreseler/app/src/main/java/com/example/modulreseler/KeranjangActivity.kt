package com.example.modulreseler

class KeranjangActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_keranjang)
    }

    fun checkout(view: View) {
        startActivity(Intent(this, PemesananActivity::class.java))
    }
}
}