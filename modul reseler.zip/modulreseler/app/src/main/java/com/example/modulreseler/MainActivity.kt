package com.example.modulreseler

package com.example.modulreseler

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Memuat fragment pertama kali saat aplikasi dibuka
        loadFragment(DashboardFragment())

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        bottomNav.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.menu_dashboard -> loadFragment(DashboardFragment())
                R.id.menu_produk -> loadFragment(ProdukFragment())
                R.id.menu_transaksi -> loadFragment(TransaksiFragment())
                R.id.menu_profil -> loadFragment(ProfilFragment())
            }
            true
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.frameContainer, fragment)
            .commit()
    }
}