package com.example.modulreseler

class `pemensananActivity.kt` : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pemesanan)
    }

    fun goPayment(view: View) {
        startActivity(Intent(this, PaymentActivity::class.java))
    }
}
}