package com.example.modulreseler

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment


class home_produkActivity : AppCompatActivity() {

        class home_produk : AppCompatActivity() {
            //function replace fragment
            private fun replaceFragment(fragment: Fragment) {
                val fragmentManager = supportFragmentManager
                val fragmentTrx = fragmentManager.beginTransaction()
                fragmentTrx.replace(R.id.fragmentContainerView, fragment)
                fragmentTrx.commit()
            }

            override fun onCreate(savedInstanceState: Bundle?) {
                super.onCreate(savedInstanceState)
                enableEdgeToEdge()
                setContentView(R.layout.activity_homeproduk)
                ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                    val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                    v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                    insets
                }

                //Instance
                val txtAccount: TextView = findViewById(R.id.textViewMenuAccount)
                val txtMenu: TextView = findViewById(R.id.textViewMenu)
                val txtCart: TextView = findViewById(R.id.textViewCart)
                val txtReport: TextView = findViewById(R.id.textViewReport)
                //event menu account click
                txtAccount.setOnClickListener {
                    replaceFragment(menufragment())
                }
                txtAccount.setOnClickListener {
                    replaceFragment(AccountFragment())
                }
                txtAccount.setOnClickListener {
                    replaceFragment(ReportFragment())
                }
                txtAccount.setOnClickListener {
                    replaceFragment(CartFragment())
                }
            }
        }