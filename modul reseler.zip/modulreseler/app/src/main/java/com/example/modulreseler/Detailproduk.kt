package com.example.modulreseler
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
class Detailproduk {


    class DetailProdukActivity : AppCompatActivity() {
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_detail_produk)
        }

        fun addToCart(view: View) {
            startActivity(Intent(this, KeranjangActivity::class.java))
        }
    }
}